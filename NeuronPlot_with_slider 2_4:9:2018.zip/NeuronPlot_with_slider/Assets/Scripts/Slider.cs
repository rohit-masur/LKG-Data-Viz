﻿//using System.Collections;
//using System.Collections.Generic;
//using UnityEngine;

//public class Slider : MonoBehaviour {


//    int newCount = Graph.getCount();

//    public void Slider_Changed(int newCount) //    { //        Graph //    } 
//}
